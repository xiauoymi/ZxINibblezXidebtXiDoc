java  $JAVA_OPTS -DWEBAPP_DIR=nibble-web/src/main/webapp/   -Dspring.profiles.active=embedded-local,aws -cp nibble-web/target/classes:target/lib/* com.nibbledebt.app.TomcatMain
