package com.nibbledebt.domain.model.account;

/**
 * @author a.salachyonok
 */
public class ImageChoice {

    private String value;

    private String body;

    public String getValue() {
        return value;
    }

    public void setValue(String value) {
        this.value = value;
    }

    public String getBody() {
        return body;
    }

    public void setBody(String body) {
        this.body = body;
    }
}
