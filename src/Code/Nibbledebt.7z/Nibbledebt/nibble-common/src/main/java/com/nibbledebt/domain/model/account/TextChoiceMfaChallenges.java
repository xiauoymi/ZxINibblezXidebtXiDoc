package com.nibbledebt.domain.model.account;

/**
 * @author a.salachyonok
 */
public class TextChoiceMfaChallenges extends MfaChallenges<TextChoiceQuestion> {
}
