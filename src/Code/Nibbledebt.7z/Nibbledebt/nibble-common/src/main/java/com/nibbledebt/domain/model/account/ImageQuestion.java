package com.nibbledebt.domain.model.account;

/**
 * @author a.salachyonok
 */

public class ImageQuestion extends Question {

    private String image;

    public String getImage() {
        return image;
    }

    public void setImage(String image) {
        this.image = image;
    }
}
