package com.nibbledebt.domain.model.account;

/**
 * @author a.salachyonok
 */
public enum MfaType {
    NON_MFA,
    TEXT,
    TEXT_CHOOSE,
    IMAGE,
    IMAGE_CHOOSE
}
