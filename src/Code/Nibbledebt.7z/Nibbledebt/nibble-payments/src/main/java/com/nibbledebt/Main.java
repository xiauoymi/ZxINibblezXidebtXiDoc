package com.nibbledebt;

import org.springframework.web.client.RestTemplate;

import com.dwolla.java.sdk.DwollaCallback;

public class Main {

	public static void main(String[] args) {
		RestTemplate client =new RestTemplate();
		
	}

}
