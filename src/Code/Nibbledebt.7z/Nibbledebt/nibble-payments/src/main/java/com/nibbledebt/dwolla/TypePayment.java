package com.nibbledebt.dwolla;

public enum TypePayment {
	
		DEFAULT,
		FEE,
		REFUND_FEE,
		REFUNDED_FEE;
	
}
