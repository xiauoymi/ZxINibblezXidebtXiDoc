@XmlSchema (
      elementFormDefault=XmlNsForm.QUALIFIED
    )
package com.nibbledebt.integration.finicity.model;

import javax.xml.bind.annotation.XmlNsForm;
import javax.xml.bind.annotation.XmlSchema;