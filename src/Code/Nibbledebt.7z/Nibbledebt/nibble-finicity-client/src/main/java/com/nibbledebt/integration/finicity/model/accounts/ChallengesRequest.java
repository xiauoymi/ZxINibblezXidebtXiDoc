package com.nibbledebt.integration.finicity.model.accounts;

/**
 * @author a.salachyonok
 */
public class ChallengesRequest extends MfaChallenges<QuestionRequest> {
}
