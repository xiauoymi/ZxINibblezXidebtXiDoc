package com.nibbledebt.integration.finicity.model.accounts;

/**
 * @author a.salachyonok
 */
public class TextQuestion extends Question{
}
