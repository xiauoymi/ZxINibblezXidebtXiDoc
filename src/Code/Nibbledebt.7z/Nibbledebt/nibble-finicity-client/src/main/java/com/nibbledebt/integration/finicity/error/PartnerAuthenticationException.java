/**
 * 
 */
package com.nibbledebt.integration.finicity.error;

/**
 * @author alam_home
 *
 */
public class PartnerAuthenticationException extends Exception {
	private static final long serialVersionUID = 6959904991300751198L;
	public PartnerAuthenticationException(Throwable t){
		super(t);
	}
}
