package com.nibbledebt.integration.finicity.model.accounts;

/**
 * @author a.salachyonok
 */
public enum MfaType {
    NON_MFA,
    TEXT,
    TEXT_CHOOSE,
    IMAGE,
    IMAGE_CHOOSE
}
