/**
 * Copyright 2015-2016. All rights reserved by Nibbledebt Inc.
 */
package com.nibbledebt.core.data.dao;

import com.nibbledebt.core.data.model.ChartImage;

/**
 * @author ust3000
 *
 */
public interface IChartImageDao extends IDao<ChartImage> {

}
