/**
 * Copyright 2015-2016. All rights reserved by Nibbledebt Inc.
 */
/**
 * @author ralam
 *
 */
package com.nibbledebt.integration.sao.finicity;