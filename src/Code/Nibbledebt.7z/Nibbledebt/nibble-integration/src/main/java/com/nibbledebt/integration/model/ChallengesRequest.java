package com.nibbledebt.integration.model;

import com.nibbledebt.domain.model.account.MfaChallenges;
import com.nibbledebt.domain.model.account.QuestionRequest;

/**
 * @author a.salachyonok
 */
public class ChallengesRequest extends MfaChallenges<QuestionRequest> {
}
