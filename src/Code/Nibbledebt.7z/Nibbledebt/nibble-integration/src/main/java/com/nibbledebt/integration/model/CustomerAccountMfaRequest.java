package com.nibbledebt.integration.model;

import com.fasterxml.jackson.annotation.JsonRootName;

/**
 * @author a.salachyonok
 */
@JsonRootName("accounts")
public class CustomerAccountMfaRequest {



}
